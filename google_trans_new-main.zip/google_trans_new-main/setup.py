from setuptools import setup

setup(
    name='google_trans_new_fix',
    version='1.0.0',
    packages=['google_trans_new_fix'],
    url='',
    license='MIT',
    author='lushan88a',
    author_email='',
    description='temp bug fix https://github.com/lushan88a/google_trans_new'
)
